import React, { useState, useEffect } from 'react';
import axios from 'axios';

const Custom = () => {
const [labels,setLabels]=useState([])
const [data,setData]=useState([])


  useEffect(() => {
    const fetchData = async () => {
      try {
        // Replace 'http://localhost:5000' with your Flask server URL
        const response = await axios.get('http://localhost:5000/sales_data', {
          params: {
            x_axis: 'Month', // Replace with your desired x_axis value
            y_axis: 'Sale_Amount' // Replace with your desired y_axis value
          }
        });

        const labels = Object.keys(response.data);
        const data = Object.values(response.data);
        setLabels(labels)
        setData(data)

    //     setChartData({
    //       labels,
    //       datasets: [
    //         {
    //           label: 'Sales Amount',
    //           data,
    //           backgroundColor: 'rgba(75, 192, 192, 0.6)',
    //         },
    //       ],
    //     });
    //     setLoading(false);
      } catch (error) {
        console.error('Error fetching data:', error);
      }
    };

    fetchData();
  }, []);

  return (
    <div className="App">
      <h1>Sales Dashboard</h1>
      {labels}
      {data}
    </div>
  );
};

export default Custom;
