const runDashboardTool = require('./tool');

const input="display sales dashboard of region east in Q4"

const res=runDashboardTool(input)

console.log(res)