import React, { useState, useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import './ChatBot.css';
import axios from 'axios';

const generateServerId = () => {
  return new Date().toISOString();
};

const pandasSend = async (data) => {
  try {
    const res = await axios.post('http://localhost:5000/api/handlechat', { 'query':data });
    console.log('Data saved successfully:', res);
  } catch (error) {
    console.error('Error saving data to backend:', error);
  }
};



const ChatBot = () => {
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState('');
  const [isOpen, setIsOpen] = useState(true);
  const location = useLocation();

  // useEffect(() => {
  //   // Close the chatbot when the location changes
  //   setIsOpen(false);
  // }, [location]);

  useEffect(() => {
    const storedServerId = localStorage.getItem('serverId');
    const currentServerId = generateServerId();

    if (storedServerId !== currentServerId) {
      // Server has restarted, clear the previous messages
      localStorage.removeItem('chatMessages');
      localStorage.setItem('serverId', currentServerId);
    } else {
      // Load messages from localStorage if server has not restarted
      const savedMessages = localStorage.getItem('chatMessages');
      if (savedMessages) {
        setMessages(JSON.parse(savedMessages));
      }
    }
  }, []);

  useEffect(() => {
    // Save messages to localStorage whenever they change
    localStorage.setItem('chatMessages', JSON.stringify(messages));
  }, [messages]);

  const handleSend = async() => {
    if (input.trim()) {
      const userMessage = { text: input, sender: 'user' };
      setMessages([...messages, userMessage]);
      setInput('');
      var link=""
      
      pandasSend(input)
      // try{
      //   const res=await axios.post('http://localhost:5000/api/chat',{'message':input});
      //   link=res.data;
      //   console.log(link)
      // }catch(error){
      //   console.log("Error")
      // }
      // Simulate bot reply (replace with actual backend call)
      setTimeout(() => {
        const botMessage = { text: `Bot replies to: ${input}`, sender: 'bot' };
        setMessages(prevMessages => [...prevMessages, botMessage]);
      }, 500);
    }
  };

  const toggleChat = () => {
    setIsOpen(!isOpen);
  };

  return (
    <div>
      <button className="chatbot-toggle-button" onClick={toggleChat}>
        💬
      </button>
      {isOpen && (
        <div className="chatbot-container">
          <div className="chatbot-header">
            ChatBot
          </div>
          <div className="chatbot-messages">
            {messages.map((msg, index) => (
              <div key={index} className={`chatbot-message ${msg.sender}`}>
                {msg.text}
              </div>
            ))}
          </div>
          <div className="chatbot-input">
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Type a message..."
            />
            <button onClick={handleSend}>Send</button>
          </div>
        </div>
      )}
    </div>
  );
};

export default ChatBot;
