// Configuration file for storing API tokens and other sensitive information
const config = {
    huggingFaceApiToken1: "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"
  };
  
  export default config;
  